<?php
/**
 * Plugin Name: ASCVD Calculator
 * Description: Calculates ASCVD 10-Year Risk Score and displays the result as a custom pop-up.
 * Version: 1.0
 * Author: Sarmiephoenix
 */

function include_sweetalert2_library() {
    wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11.0.15/dist/sweetalert2.min.js', array('jquery'), '11.0.15', true);
}
add_action('wp_enqueue_scripts', 'include_sweetalert2_library');

function calculateASCVDRisk($age, $gender, $totalCholesterol, $hdlCholesterol, $bpSystolic, $isDiabetic, $isSmoker) {
    $ageCoeff = 17.83;
    $totalCholCoeff = 0.055;
    $hdlCholCoeff = -0.206;
    $bpSystolicCoeff = 0.0118;
    $diabetesCoeff = 0.658;
    $smokingCoeff = 0.927;

    $ageMultiplier = $age * $ageCoeff;
    $totalCholMultiplier = $totalCholesterol * $totalCholCoeff;
    $hdlCholMultiplier = $hdlCholesterol * $hdlCholCoeff;
    $bpSystolicMultiplier = $bpSystolic * $bpSystolicCoeff;
    $diabetesMultiplier = $isDiabetic ? $diabetesCoeff : 0;
    $smokingMultiplier = $isSmoker ? $smokingCoeff : 0;

    $ascvdScore = 5.337 + $ageMultiplier + $totalCholMultiplier + $hdlCholMultiplier + $bpSystolicMultiplier + $diabetesMultiplier + $smokingMultiplier;

    return $ascvdScore;
}

function displayASCVDCalculator() {
    ob_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $totalCholesterol = $_POST['total_cholesterol'];
        $hdlCholesterol = $_POST['hdl_cholesterol'];
        $bpSystolic = $_POST['bp_systolic'];
        $isDiabetic = isset($_POST['is_diabetic']);
        $isSmoker = isset($_POST['is_smoker']);

        $ascvdScore = calculateASCVDRisk($age, $gender, $totalCholesterol, $hdlCholesterol, $bpSystolic, $isDiabetic, $isSmoker);
        
        // Create a custom pop-up
        echo "<div id='ascvd-popup' class='ascvd-popup'>
            <div class='ascvd-popup-content'>
                <p>Your ASCVD 10-Year Risk Score is: " . round($ascvdScore, 2) . "%</p>
                <button id='close-popup' class='close-popup'>Close</button>
            </div>
        </div>
        <script>
            document.getElementById('close-popup').addEventListener('click', function() {
                document.getElementById('ascvd-popup').style.display = 'none';
            });
        </script>";
    }
    ?>
    <form method="post">
        <label for="age">Age:</label>
        <input type="number" name="age" required><br>

        <label for="gender">Gender:</label>
        <select name="gender" required>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select><br>

        <label for="total_cholesterol">Total Cholesterol:</label>
        <input type="number" name="total_cholesterol" required><br>

        <label for="hdl_cholesterol">HDL Cholesterol:</label>
        <input type="number" name="hdl_cholesterol" required><br>

        <label for="bp_systolic">Systolic Blood Pressure:</label>
        <input type="number" name="bp_systolic" required><br>

        <label for="is_diabetic">Diabetic:</label>
        <input type="checkbox" name="is_diabetic"><br>

        <label for="is_smoker">Smoker:</label>
        <input type="checkbox" name="is_smoker"><br>

        <input type="submit" value="Calculate ASCVD Risk">
    </form>
    <?php

    return ob_get_clean();
}

add_shortcode('ascvd_calculator', 'displayASCVDCalculator');
